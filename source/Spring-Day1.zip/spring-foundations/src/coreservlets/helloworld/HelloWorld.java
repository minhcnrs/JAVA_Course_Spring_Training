package coreservlets.helloworld;

public interface HelloWorld {

  public void execute();

}
