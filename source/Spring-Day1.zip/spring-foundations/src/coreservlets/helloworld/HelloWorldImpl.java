package coreservlets.helloworld;

public class HelloWorldImpl implements HelloWorld {

  public void execute() {
    System.out.println("Hello World!");
  }

}
