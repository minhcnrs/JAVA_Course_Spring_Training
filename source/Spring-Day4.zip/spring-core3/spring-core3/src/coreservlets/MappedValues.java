package coreservlets;

import java.util.Map;

public class MappedValues {

  public void setMap(Map<Integer,Integer>map){
    System.out.println(map);
  }
  
}
