package coreservlets;

import org.apache.log4j.Logger;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;


public class LifecycleCallbackDemoTest {

  private static final Logger log = Logger.getLogger(LifecycleCallbackDemoTest.class);
  
  @BeforeClass
  public static void execOnceBeforeAllTestCases(){
    log.info("execOnceBeforeAllTestCases");
  }

  @Before
  public void execBeforeEachTestCase(){
    log.info("execBeforeEachTestCase");
  }
  
  @Test
  public void testDemo00(){
    log.info("testDemo00");
  }

  @Test
  public void testDemo01(){
    log.info("testDemo01");
  }

  @After
  public void execAfterEachTestCase(){
    log.info("execAfterEachTestCase");
  }

  @AfterClass
  public static void execAfterAllTestCases(){
    log.info("execAfterAllTestCases");
  }

}
