package coreservlets;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * Mock CustomerDao implementation.
 */
public class MockCustomerDao implements CustomerDao {

  /** Cached customers */
  private List<Customer> customers;

  /**
   * Constructs a new MockCustomerQuery instance initialized with the argued
   * customer list.
   * 
   * @param customers no requirements
   */
  public MockCustomerDao(List<Customer> customers) {
    this.customers = customers != null ? customers : new ArrayList<Customer>();
    Collections.sort(customers, COMPARATOR);
  }

  /*
   * @see coreservlets.CustomerQuery#getCustomerByName(java.lang.String)
   */
  public Customer getCustomerByName(String name) {
    Customer key = new Customer();
    key.setName(name);
    int index = Collections.binarySearch(this.customers, key, COMPARATOR);
    if(index >= 0){
      return this.customers.get(index);
    }
    return null;
  }

  /*
   * @see coreservlets.CustomerDao#getCustomerCount()
   */
  public int getCustomerCount() {
    return this.customers.size();
  }

  /*
   * @see coreservlets.CustomerDao#insert(coreservlets.Customer[])
   */
  public void insert(Customer... customers) {
    if(customers == null){
      return;
    }
    for(Customer customer : customers){
      int index =
        Collections.binarySearch(this.customers, customer, COMPARATOR);
      if(index >= 0){
        throw new IllegalArgumentException("Error: customer."
          + " Failed to insert duplicate: "
          + customer);
      }
      this.customers.add(-index - 1, customer);
    }
  }

  private static final Comparator<Customer> COMPARATOR =
    new Comparator<Customer>(){
      public int compare(Customer customer, Customer other) {
        return customer.getName().compareTo(other.getName());
      }
    };
}
