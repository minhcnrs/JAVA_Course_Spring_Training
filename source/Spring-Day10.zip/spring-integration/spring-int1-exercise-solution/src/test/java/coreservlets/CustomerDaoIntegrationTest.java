package coreservlets;

import static org.junit.Assert.assertEquals;

import javax.annotation.Resource;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.simple.SimpleJdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.transaction.annotation.Transactional;

/**
 * Demo performing a limited set of functional/integration tests.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(
  locations={"/coreservletsContext.xml","/coreservletsTestContext.xml"})
@TransactionConfiguration
@Transactional
public class CustomerDaoIntegrationTest {

  @Resource
  private CustomerDao service;
  
  @Resource
  private SimpleJdbcTemplate jdbc;
      
  @Test
  public void testGetCustomerByName(){        
    Customer expected = getCustomer();
    Customer received = service.getCustomerByName(expected.getName());
    assertCustomer(expected, received);
  }
  
  @Test
  public void testGetCustomerCount(){
    int count = service.getCustomerCount();
    int expected = getCustomerCount();
    assert count == expected;
  }
  
  @Test
  public void testInsert(){
    int count = getCustomerCount();
    assertCustomerCount(count);
    Customer toBeInserted = getNewCustomer();
    service.insert(toBeInserted);    
    assertCustomerCount(count + 1);
  }
  
  /**
   * Specifies a Customer test vector.
   */
  private static Customer getCustomer(){
    return new Customer("jjoe","Java Joe");
  }
  
  /**
   * Specifies a new Customer test vector.
   */
  private static Customer getNewCustomer(){
    return new Customer("t-id-00","t-name-00");
  }

  /**
   * Specifies the Customer stored count test vector.
   */
  private static int getCustomerCount(){
    return 2;
  }

  private static void assertCustomer(Customer expected, Customer customer){
    if(expected == null){
      assert customer == null;
      return;
    }
    assert customer != null;
    assert customer.getId().equals(expected.getId());
    assert customer.getName().equals(expected.getName());
  }
  
  private void assertCustomerCount(int expectedCount){
    int storedCount = jdbc.queryForInt("select count(*) from customer");
    assertEquals(expectedCount, storedCount);
  }
}
