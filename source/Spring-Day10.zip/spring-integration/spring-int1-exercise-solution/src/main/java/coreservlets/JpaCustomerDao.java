package coreservlets;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceException;

public class JpaCustomerDao implements CustomerDao {

  @PersistenceContext(unitName="coreservlets")
  private EntityManager entityManager;

  public Customer getCustomerByName(String customerName) {
    if(customerName == null){
      throw new IllegalArgumentException("Required: " + customerName);
    }
    try{
      return (Customer) this.entityManager.createQuery(
        "select c from Customer c where c.name = :customerName")
        .setParameter("customerName", customerName)
        .getSingleResult();
    }
    catch(NoResultException e){
      return null;
    }
  }
  
  public int getCustomerCount(){
    return ((Number) this.entityManager.createQuery(
      "select count(*) from Customer")
      .getSingleResult())
      .intValue();  
  }
  
  public void insert(Customer...customers) {
    if(customers == null){
      return;
    }
    for(Customer customer : customers){
      try{
        this.entityManager.persist(customer);
        this.entityManager.flush();
      }
      catch(PersistenceException e){
        throw new IllegalArgumentException("Invalid: customer."
          + " Failed to store duplicate value: " + customer);
      }
    }
  }
}
