package coreservlets;

import java.sql.ResultSet;
import java.sql.SQLException;

import javax.sql.DataSource;

import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
import org.springframework.jdbc.core.simple.SimpleJdbcTemplate;

/**
 * CustomerDao implemented using Spring JDBC template support.
 */
public class SpringJdbcCustomerDao implements CustomerDao {

  /** The Spring JDBC template. */
  private SimpleJdbcTemplate jdbc;

  /**
   * Constructs a new instance. All JDBC operations are performed using
   * connections from the specified data source.
   * 
   * @param dataSource required.
   */
  public SpringJdbcCustomerDao(DataSource dataSource) {
    if(dataSource == null){
      throw new IllegalArgumentException("Required: data source");
    }
    this.jdbc = new SimpleJdbcTemplate(dataSource);
  }

  /*
   * @see coreservlets.CustomerDao#getCustomerByName(java.lang.String)
   */
  public Customer getCustomerByName(String customerName) {
    try{
      return this.jdbc.queryForObject(
        "select id, name from customer where name = ?"
        , customerRowMapper
        , customerName);
    }
    catch(EmptyResultDataAccessException e){
      return null;
    }
  }
  
  /*
   * @see coreservlets.CustomerDao#getCustomerCount()
   */
  public int getCustomerCount(){
    return jdbc.queryForInt("select count(*) from customer");
  }
  
  /*
   * @see coreservlets.CustomerDao#insert(coreservlets.Customer[])
   */
  public void insert(Customer...customers) {
    if(customers == null){
      return;
    }
    for(Customer customer : customers){
      try{
        jdbc.update(
          "insert into customer (id, name) values (?, ?)",
          customer.getId(),
          customer.getName());
      }
      catch(DataIntegrityViolationException e){
        throw new IllegalArgumentException("Invalid: customer."
          + " Failed to store duplicate value: " + customer);
      }
    }
  }

  private ParameterizedRowMapper<Customer> customerRowMapper =
    new ParameterizedRowMapper<Customer>(){
      public Customer mapRow(ResultSet rslt, int rowNum) throws SQLException {
        return new Customer(rslt.getString("id"), rslt.getString("name"));
      }
    };
}
