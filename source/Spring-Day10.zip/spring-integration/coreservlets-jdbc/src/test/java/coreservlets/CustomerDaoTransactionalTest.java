package coreservlets;

import static org.junit.Assert.assertEquals;

import javax.annotation.Resource;

import org.junit.After;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.jdbc.core.simple.SimpleJdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.AfterTransaction;
import org.springframework.test.context.transaction.BeforeTransaction;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.transaction.annotation.Transactional;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(
  locations={"/coreservletsContext.xml","/coreservletsTestContext.xml"})
@TransactionConfiguration
@Transactional
public class CustomerDaoTransactionalTest {

  @Resource
  private CustomerDao service;
  
  @Resource
  private SimpleJdbcTemplate jdbc;
  
  @BeforeTransaction
  @AfterTransaction
  public void beforeAndAfterTx() {
    assertCustomerCount(2);
  }
  
  @After
  public void afterTestCaseWithinTx(){
    assertCustomerCount(3); // before rollback
  }
  
  @Test(expected=IllegalArgumentException.class)
  public void verifyUniqueConstraint(){
    assertCustomerCount(2);
    service.insert(new Customer("t-id","t-name"));
    service.insert(new Customer("t-id","t-name"));
  }
  
  private void assertCustomerCount(int expectedCount){
    int storedCount = jdbc.queryForInt("select count(*) from customer");
    assertEquals(expectedCount, storedCount);
  }
}
