package coreservlets;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity 
@Table
public class Customer implements Serializable {

  private static final long serialVersionUID = 5881889957977560010L;

  @Id @Column
  private String id;

  @Column(nullable = false, unique = true, length = 64)
  private String name;

  public Customer() {
    super();
  }

  public Customer(String id, String name) {
    this.id = id;
    this.name = name;
  }

  public void setId(String id) {
    this.id = id;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getId() {
    return id;
  }

  public String getName() {
    return name;
  }

  public String toString() {
    return getClass().getSimpleName()
      + " id="
      + this.id
      + ", name="
      + this.name;
  }
}
