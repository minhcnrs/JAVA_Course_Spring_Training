package coreservlets;

public interface CustomerDao {
 
  /**
   * Retrieves a stored customer with a matching name.
   * 
   * @param name required
   * @return a non-null value if a stored customer with a matching name is
   * identified. Otherwise, null.
   */
  public Customer getCustomerByName(String name);
  
  /**
   * Provides the quantity of stored customer records
   * 
   * @return an integer greater/equal-to zero
   */
  public int getCustomerCount();
  
  /**
   * Inserts the argued customer object array. 
   * 
   * @param customers zero or more elements. Storing each element must
   * maintain a unique set of stored customer elements
   * @throws IllegalArgumentException for parameter spec violations
   */
  public void insert(Customer...customers);
  
}
