* Install coreservlets root POM only

mvn install

* Install coreservlets root POM and build/install all child projects

mvn install -Pall

* Install coreservlets root POM and web modules

mvn install -Pweb
