package coreservlets;


public class CustomerLookupBean {

  private CustomerDao customerDao;
  
  private String name;
  
  private Customer customer;
  
  public CustomerLookupBean(){
    super();
  }

  public void setCustomerDao(CustomerDao customerDao){
    this.customerDao = customerDao;
  }
  
  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public Customer getCustomer() {
    return customer;
  }

  public void setCustomer(Customer customer) {
    this.customer = customer;
  }
  
  public String lookupCustomer(){
    this.customer = null;
    if(this.name == null || this.name.trim().length()==0){
      return null;
    }
    this.customer = this.customerDao.getCustomerByName(this.name);
    return null;
  }
  
}
