package coreservlets;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceException;

/**
 * CustomerDao interface implemented using JPA support.
 */
public class JpaCustomerDao implements CustomerDao {

  @PersistenceContext(unitName="coreservlets")
  private EntityManager entityManager;

  /**
   * Constructs a new instance. 
   * 
   * @param entityManager required.
   */
  public JpaCustomerDao(){
    super();
  }
  
  /**
   * Constructs a new instance. All operations are performed using
   * the specified entity manager.
   * 
   * @param entityManager required.
   */
  public JpaCustomerDao(EntityManager entityManager) {
    if(entityManager == null){
      throw new IllegalArgumentException("Required: entity manager");
    }
    this.entityManager = entityManager;
  }
  
  /*
   * @see coreservlets.CustomerDao#getCustomerByName(java.lang.String)
   */
  public Customer getCustomerByName(String customerName) {
    if(customerName == null){
      throw new IllegalArgumentException("Required: " + customerName);
    }
    try{
      return (Customer) this.entityManager.createQuery(
        "select c from Customer c where c.name = :customerName")
        .setParameter("customerName", customerName)
        .getSingleResult();
    }
    catch(NoResultException e){
      return null;
    }
  }
  
  /*
   * @see coreservlets.CustomerDao#getCustomerCount()
   */
  public int getCustomerCount(){
    return ((Number) this.entityManager.createQuery(
      "select count(*) from Customer")
      .getSingleResult())
      .intValue();  
  }
  
  /*
   * @see coreservlets.CustomerDao#insert(coreservlets.Customer[])
   */
  public void insert(Customer...customers) {
    if(customers == null){
      return;
    }
    for(Customer customer : customers){
      try{
        this.entityManager.persist(customer);
        this.entityManager.flush();
      }
      catch(PersistenceException e){
        throw new IllegalArgumentException("Invalid: customer."
          + " Failed to store duplicate value: " + customer);
      }
    }
  }
}
