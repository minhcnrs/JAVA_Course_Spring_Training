package coreservlets;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {
  public static void main(String[]args){
        
    if(args.length == 0){
      System.err.println("Missing required parameter <Customer name>. Exiting on error.");
      System.exit(1);
    }
    System.out.println("Searching for: " + args[0]);

    BeanFactory factory = new ClassPathXmlApplicationContext(
      "/coreservletsContext.xml");
    CustomerDao service = (CustomerDao) factory.getBean("customerQuery");
    Customer customer = service.getCustomerByName(args[0]);

    System.out.println("Found: " + customer);

  }
}
