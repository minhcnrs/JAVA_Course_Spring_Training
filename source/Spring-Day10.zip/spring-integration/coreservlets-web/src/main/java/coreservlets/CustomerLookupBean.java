package coreservlets;


/**
 * JSF backing bean. Performs several functions including adapting UI requests
 * to underlying service mechanisms, captures name properties, and caches
 * customer information.
 */
public class CustomerLookupBean {

  /** Customer persistence services. */
  private CustomerDao customerDao;
  
  /** Name value provided for capturing a request parameter. */
  private String name;
  
  /** Cached customer. */
  private Customer customer;
  
  /**
   * Constructs a new instance.
   */
  public CustomerLookupBean(){
    super();
  }

  public void setCustomerDao(CustomerDao customerDao){
    this.customerDao = customerDao;
  }  

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public Customer getCustomer() {
    return customer;
  }

  public void setCustomer(Customer customer) {
    this.customer = customer;
  }
  
  /**
   * Uses the current name value as a parameter for looking up customer
   * information. Results are stored and accessible using the customer
   * property.
   * 
   * @return null
   */
  public String lookupCustomer(){
    this.customer = null;
    if(this.name == null || this.name.trim().length()==0){
      return null;
    }
    this.customer = this.customerDao.getCustomerByName(this.name);
    return null;
  }
  
}
