package coreservlets;

/**
 * Sample bean that's not just a java.lang.Object.
 */
public class Bean {
}
